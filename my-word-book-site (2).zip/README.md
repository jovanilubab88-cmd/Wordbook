# My Word Book — with AI voice

A picture dictionary for grades 5 to 8, with a Chapter 2 word list, "Learn more" explanations, a Spelling section (practice and test), and a picture game. Every word, sentence, and explanation is read aloud by a natural AI voice. When you add a word, AI writes the meaning, an example sentence, an explanation, the syllables, and a picture for you.

This runs as your own website on Netlify (free plan) and uses OpenAI for the voice and the writing.

## What you need

- A computer (setup is much easier there than on a phone)
- A free **GitHub** account: https://github.com
- A free **Netlify** account: https://netlify.com (you can sign up with GitHub)
- An **OpenAI API account** with a payment method: https://platform.openai.com
  OpenAI charges a small amount each time a new word is spoken or written. Each word's audio is made once and saved on your site, so playing it again costs nothing.

## Setup (about 15 minutes)

1. **Get an OpenAI key.** At https://platform.openai.com go to API keys, create a new key, and copy it. Keep it private.

2. **Put the files on GitHub.**
   - Unzip `my-word-book-site.zip`.
   - On GitHub, click **New repository**, name it `my-word-book`, and create it.
   - Click **uploading an existing file**, then open the unzipped folder and drag in the files **inside** it (`index.html`, `netlify`, `package.json`, `netlify.toml`, `README.md`) — not the zip file and not the outer folder. Click **Commit changes**.

3. **Create the site on Netlify.**
   - In Netlify click **Add new site → Import an existing project → GitHub**, then choose `my-word-book`.
   - Leave the build settings as they are and click **Deploy**.

4. **Add your two secrets.** In Netlify open your site → **Site configuration → Environment variables → Add a variable**:
   - `OPENAI_API_KEY` = the key from step 1
   - `ADMIN_PIN` = a PIN you choose (for example `4821`). Only people with this PIN can add or change words.

5. **Redeploy.** Go to **Deploys → Trigger deploy → Deploy site**. Your secrets are used from this deploy on.

6. **Open your site** (the link looks like `something.netlify.app`). Tap a word and you'll hear the AI voice. Tap **+ Add word** and enter your PIN the first time.

## Using it

- **🗣️ button:** pick an AI voice (Coral, Nova, Shimmer, Sage, Fable, Ash, Echo) and the speed. Device voices are listed too and work without internet.
- **+ Add word:** type a word and the meaning, sentence, syllables and picture fill in. Check them, then tap Save.
- **Add many words at once:** type one word per line. Add `| 7` after a word to set its grade (5 to 8).
- If the AI voice can't be reached, the app switches to the device's own voice so kids can keep going.

## Optional settings

Add these environment variables in Netlify if you want to change models later:
- `VOICE_MODEL` (default `gpt-4o-mini-tts`)
- `TEXT_MODEL` (default `gpt-4o-mini`)

## Good to know

- Anyone with your site link can listen to words. The voice only reads short texts (up to 250 characters), and saved audio is reused, so costs stay low. You can set a monthly spending limit in your OpenAI account under Billing → Limits.
- Words you add are stored on your Netlify site. Stars and voice choices are saved on each device.
- To change your PIN, edit `ADMIN_PIN` in Netlify and redeploy.
