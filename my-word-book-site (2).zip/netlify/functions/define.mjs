// Writes the meaning, example sentence, syllables and picture for new words.
const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });

export default async (req) => {
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  if (!process.env.ADMIN_PIN || !process.env.OPENAI_API_KEY) return json({ error: "not_configured" }, 500);

  const body = await req.json().catch(() => ({}));
  if (String(body.pin || "") !== process.env.ADMIN_PIN) return json({ error: "bad_pin" }, 401);
  const prompt = String(body.prompt || "").slice(0, 8000);
  if (!prompt) return json({ error: "missing_prompt" }, 400);

  const r = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: process.env.TEXT_MODEL || "gpt-4o-mini",
      response_format: { type: "json_object" },
      messages: [{ role: "user", content: prompt }],
    }),
  });
  if (!r.ok) {
    console.error("define failed", r.status, await r.text());
    return json({ error: "ai_failed" }, 502);
  }
  const data = await r.json();
  try {
    return json({ result: JSON.parse(data.choices?.[0]?.message?.content || "{}") });
  } catch {
    return json({ error: "ai_bad_answer" }, 502);
  }
};

export const config = { path: "/api/define" };
