// Turns a word or sentence into natural AI speech.
// Each piece of audio is made once, saved, and replayed for free after that.
import { getStore } from "@netlify/blobs";
import { createHash } from "node:crypto";

const VOICES = new Set(["coral", "nova", "shimmer", "sage", "fable", "ash", "echo", "alloy", "ballad", "onyx", "verse"]);
const STYLE =
  "Speak warmly and clearly, like a friendly teacher reading to young children. " +
  "Pronounce every word carefully, with natural, cheerful expression.";

function hash(s) {
  return createHash("sha256").update(s).digest("hex");
}

export default async (req) => {
  const url = new URL(req.url);
  const text = (url.searchParams.get("text") || "").trim();
  const voice = VOICES.has(url.searchParams.get("voice")) ? url.searchParams.get("voice") : "coral";
  if (!text || text.length > 250) return new Response("Text missing or too long", { status: 400 });
  if (!process.env.OPENAI_API_KEY) return new Response("Voice not set up", { status: 500 });

  const model = process.env.VOICE_MODEL || "gpt-4o-mini-tts";
  const headers = { "Content-Type": "audio/mpeg", "Cache-Control": "public, max-age=31536000, immutable" };
  const store = getStore("voice");
  const key = hash(`${model}|${voice}|${text}`);

  const saved = await store.get(key, { type: "arrayBuffer" });
  if (saved) return new Response(saved, { headers });

  const request = { model, voice, input: text, response_format: "mp3" };
  if (model.startsWith("gpt-")) request.instructions = STYLE;

  const r = await fetch("https://api.openai.com/v1/audio/speech", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(request),
  });
  if (!r.ok) {
    console.error("speak failed", r.status, await r.text());
    return new Response("Voice failed", { status: 502 });
  }
  const audio = await r.arrayBuffer();
  await store.set(key, audio);
  return new Response(audio, { headers });
};

export const config = { path: "/api/speak" };
