// Saves the words you add, so everyone who opens the site sees them.
import { getStore } from "@netlify/blobs";

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });

const text = (v, max) => String(v ?? "").trim().slice(0, max);

function cleanWord(x = {}) {
  const w = text(x.w, 40).toLowerCase();
  if (!w) return null;
  const s = (Array.isArray(x.s) ? x.s : [w]).map((p) => text(p, 20)).filter(Boolean).slice(0, 10);
  const g = Math.min(8, Math.max(5, parseInt(x.g, 10) || 5));
  const k = ["noun", "action", "describing"].includes(x.k) ? x.k : "noun";
  return {
    w, s: s.length ? s : [w], k, g,
    c: text(x.c, 30) || "More words",
    p: text(x.p, 16) || "📝",
    d: text(x.d, 300),
    e: text(x.e, 300),
    x: text(x.x, 600),
  };
}

export default async (req) => {
  const store = getStore("wordbook");
  const words = (await store.get("words", { type: "json" })) || [];

  if (req.method === "GET") return json({ words });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  if (!process.env.ADMIN_PIN) return json({ error: "not_configured" }, 500);
  const body = await req.json().catch(() => ({}));
  if (String(body.pin || "") !== process.env.ADMIN_PIN) return json({ error: "bad_pin" }, 401);

  if (body.action === "save") {
    const word = cleanWord(body.word);
    if (!word || !word.d) return json({ error: "invalid_word" }, 400);
    const next = words.filter((x) => x.w !== word.w).concat(word);
    await store.setJSON("words", next);
    return json({ words: next });
  }
  if (body.action === "delete") {
    const w = text(body.w, 40).toLowerCase();
    const next = words.filter((x) => x.w !== w);
    await store.setJSON("words", next);
    return json({ words: next });
  }
  return json({ error: "unknown_action" }, 400);
};

export const config = { path: "/api/words" };
